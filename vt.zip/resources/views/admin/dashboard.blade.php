@extends('admin.layouts.app_admin')

@section('content')
<div class="container">

    <div class="row">
        <div class="col-sm-12">
            <div class="jumbotron text-center">
                <h2>Добро пожаловать</h2>
                <p>Это альфа версия административной панели, которая
                разрабатывается для управления сайтом кафедры ВТ
                </p>
            </div>
        </div>
    </div>

</div>
@endsection