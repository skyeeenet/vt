<ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="{{route('admin.index')}}">{{$parent}}</a></li>
    <li class="breadcrumb-item active">{{$active}}</li>
</ol>