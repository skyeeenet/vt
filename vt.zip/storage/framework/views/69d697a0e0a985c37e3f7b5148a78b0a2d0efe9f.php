<?php $__env->startSection('content'); ?>
<main>
    <div class="errors text-center">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li> <?php echo e($error); ?> </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <section class="container mb-3">
        <form action="<?php echo e(route('messages.store')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="to">Кому отправить сообщение</label>
                <select class="form-control" name="user" id="to">
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($user->id != Auth::id()): ?> <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option> <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <label for="message">Сообщение</label>
            <textarea class="form-control" name="message" id="message" cols="30" rows="10"></textarea>
            <div class="form-group mt-2">
                <label for=""></label>
                <img src="<?php echo e(captcha_src()); ?>" alt="captcha" class="captcha-img" data-refresh-config="default"><a href="#" id="refresh"><small>обновить</small></a></p>
            </div>
            <input type="text" name="captcha" placeholder="Ответ" required/>
            <button class="btn btn-primary mt-1" type="submit">Отправить</button>
        </form>
    </section>
    <section>
        <table class="table text-center">
            <thead>
                <tr>
                    <th>Время отправки</th>
                    <th>Отправитель</th>
                    <th>Получатель</th>
                    <th>Сообщение</th>
                    <th>Очистить</th>
                </tr>
            </thead>
            <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($message->created_at); ?></td>
                    <td><?php if($message->from == Auth::id()): ?> Вы <?php else: ?> <?php echo e($message->userFrom['name']); ?> <?php endif; ?></td>
                    <td><?php if($message->to == Auth::id()): ?> Вы <?php else: ?> <?php echo e($message->userTo['name']); ?> <?php endif; ?></td>
                    <td><?php echo e($message->message); ?></td>
                    <td>
                        <form action="<?php echo e(route('messages').'/delete/'.$message->id); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <button class="btn btn-danger">Clear</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </section>
</main>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script
            src="https://code.jquery.com/jquery-3.3.1.min.js"
            integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8="
            crossorigin="anonymous">
    </script>
    <script>
        $(document).ready(function () {
            $('.message a').click(function(e){
                e.preventDefault();
                console.log('test');
                $('form').animate({height: "toggle", opacity: "toggle"}, "slow");
            });
            $('#refresh').on('click',function(){
                var captcha = $('img.captcha-img');
                var config = captcha.data('refresh-config');
                $.ajax({
                    method: 'GET',
                    url: '/get_captcha/' + config,
                }).done(function (response) {
                    captcha.prop('src', response);
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('public.layouts.basic', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>