<?php $__env->startSection('content'); ?>
    <div class="container">
        <h3 class="mt-3 mb-3">Создание текста</h3>
        <form action="<?php echo e(route('admin.content.text.store')); ?>" method="post">
            <?php echo e(csrf_field()); ?>

            <div class="form-group">
                <label class="d-block" for="description">Описание</label>
                <textarea name="description" id="description" cols="40"></textarea>
            </div>
            <div class="form-group">
                <label for="body">Содержание</label>
                <textarea name="body" id="body"></textarea>
            </div>
            <button class="btn btn-primary" type="submit">Создать</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function() {
            $('#body').summernote();
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app_admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>