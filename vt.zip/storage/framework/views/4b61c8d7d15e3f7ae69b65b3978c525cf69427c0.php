<?php $__env->startSection('title'); ?> Навигация <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
        <div class="container">
            <?php $__env->startComponent('admin.components.breadcrumbs'); ?>
                <?php $__env->slot('parent'); ?> Главная <?php $__env->endSlot(); ?>
                <?php $__env->slot('active'); ?> Меню <?php $__env->endSlot(); ?>
            <?php echo $__env->renderComponent(); ?>
        </div>
    <div class="container">
        <div class="jumbotron text-center">
            <h2>Редактирование Навигации</h2>
            <h4>Текущие меню навигации</h4>
            <form action="<?php echo e(route('admin.header.menu.create')); ?>" method="post">
                <?php echo e(csrf_field()); ?>

                <p>Название пункта меню: <input type="text" name="item_menu"></p>
                <p>URL адрес: <input type="text" name="url_menu"></p>
                <p><input class="btn btn-primary" type="submit" value="Добавить пункт меню"></p>
            </form>
            <table class="table mt-5">
                <thead>
                    <tr>
                        <th>Название пункта</th>
                        <th>URL Адрес</th>
                        <th>Редактировать</th>
                        <th>Удалить</th>
                    </tr>
                </thead>
                <tbody>
                <?php if(isset($navbar)): ?>
                <?php $__empty_1 = true; $__currentLoopData = $navbar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($element->item); ?></td>
                        <td><?php echo e($element->url); ?></td>
                        <td><a class="btn btn-primary" href="<?php echo e('/admin/header/submenu/'.$element->id); ?>"><i class="fas fa-edit"></i></a></td>
                        <td>
                            <form action="<?php echo e(route('admin.header.menu').'/destroy/'.$element->id); ?>" method="post">
                                <?php echo e(csrf_field()); ?>

                                <button type="submit" class="btn btn-danger"><i class="far fa-trash-alt"></i></button>
                            </form>
                        </td>
                        <!--<td><i class="far fa-trash-alt"></i></td>-->
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td>Нет пунктов меню</td>
                    </tr>
                <?php endif; ?>
                    <?php else: ?>
                <tr>
                    <td><b>Данные недоступны</b></td>
                    <td><b>Данные недоступны</b></td>
                </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app_admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>