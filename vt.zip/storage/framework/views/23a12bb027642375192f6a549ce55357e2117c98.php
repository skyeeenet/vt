<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-6 col-12"><p class="mt-3">Имя пользователя: <?php echo e($user->name); ?></p>
                <p>Email: <?php echo e($user->email); ?></p>
                <?php if($user->image == null): ?>
                    <div>
                        <p>Загрузить изображение профиля ?</p>
                        <form enctype="multipart/form-data" action="<?php echo e(route('user.update')); ?>" method="post">
                            <?php echo e(csrf_field()); ?>

                            <p>Новый: <input type="file" id="file" name="image"></p>
                            <ul id="list" style="list-style: none;"></ul>
                            <button class="btn btn-primary" type="submit">Загрузить</button>
                        </form>
                    </div>
                <?php else: ?>
                    <div>
                        <img width="400px" src="<?php echo e($user->image); ?>" alt="user-profile-photo">
                        <p>Обновить изображение профиля ?</p>
                        <form enctype="multipart/form-data" action="<?php echo e(route('user.update')); ?>" method="post">
                            <?php echo e(csrf_field()); ?>

                            <p>Новый: <input type="file" id="file" name="image"></p>
                            <ul id="list" style="list-style: none;"></ul>
                            <button class="btn btn-primary" type="submit">Обновить</button>
                        </form>
                    </div>
                <?php endif; ?></div>
            <div class="col-md-6 col-12">
                <p class="mt-3">О себе: </p>
                <?php if($user->description == null): ?>
                    <p>Добавить информацию о себе ?</p>
                    <form action="<?php echo e(route('user.update')); ?>" method="post">
                        <?php echo e(csrf_field()); ?>

                        <textarea name="description" id="description" cols="45" rows="10"></textarea>
                        <button class="btn btn-primary" type="submit">Добавить</button>
                    </form>
                <?php else: ?>
                    <p><?php echo e($user->description); ?></p>
                    <p>Обновить информацию о себе ?</p>
                    <form action="<?php echo e(route('user.update')); ?>" method="post">
                        <?php echo e(csrf_field()); ?>

                        <textarea name="description" id="description" cols="45" rows="10"></textarea>
                        <br>
                        <button class="btn btn-primary" type="submit">Обновить</button>
                    </form>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        function showFile(e) {
            var files = e.target.files;
            for (var i = 0, f; f = files[i]; i++) {
                if (!f.type.match('image.*')) continue;
                var fr = new FileReader();
                fr.onload = (function(theFile) {
                    return function(e) {
                        var li = document.createElement('li');
                        li.innerHTML = "<img style='max-width:100px;max-height:100px;' src='" + e.target.result + "' />";
                        document.getElementById('list').insertBefore(li, null);
                    };
                })(f);

                fr.readAsDataURL(f);
            }
        }
        document.getElementById('file').addEventListener('change', showFile, false);
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app_admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>