<?php $__env->startSection('title'); ?> Редактирование подпункта <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="jumbotron">
        <div class="d-flex flex-column">
            <h2>Редактирование подпункта</h2>
            <form action="<?php echo e('/admin/header/submenu/update/'.$submenu->id); ?>" method="post">
                <?php echo e(csrf_field()); ?>

                <div class="form-group">
                    <label for="sub-menu-item">Подпункт</label>
                    <input type="text" class="form-control" name="sub-menu-item" id="sub-menu-item" value="<?php echo e($submenu->value); ?>">
                </div>
                <div class="form-group">
                    <label for="sub-url-menu">URL Адрес</label>
                    <input type="text" class="form-control" name="sub-url-menu" id="sub-url-menu" value="<?php echo e($submenu->url); ?>">
                </div>
                <button type="submit" class="btn btn-primary">Добавить</button>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app_admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>