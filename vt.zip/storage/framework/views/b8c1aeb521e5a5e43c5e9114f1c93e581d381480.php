<?php $__env->startSection('content'); ?>
    <div class="container">
        <form action="<?php echo e(route('admin.graphics').'/update/'.$graphic->id); ?>" method="post">
            <?php echo e(csrf_field()); ?>

            <div class="form-group">
                <label for="type">Тип графика</label>
                <select class="form-control" name="type" id="type">
                    <option <?php if($graphic->type == 'Первая аттестация'): ?> selected <?php endif; ?> value="Первая аттестация">Первая аттестация</option>
                    <option <?php if($graphic->type == 'Вторая аттестация'): ?> selected <?php endif; ?> value="Вторая аттестация">Вторая аттестация</option>
                    <option <?php if($graphic->type == 'Сессия'): ?> selected <?php endif; ?> value="Сессия">Сессия</option>
                    <option <?php if($graphic->type == 'Каникулы'): ?> selected <?php endif; ?> value="Каникулы">Каникулы</option>
                </select>
            </div>
            <div class="form-group">
                <label for="date">Сроки</label>
                <input class="form-control" type="date" name="date_begin" id="date" value="<?php echo e($graphic->begin); ?>">
                <input class="form-control" type="date" name="date_end" value="<?php echo e($graphic->end); ?>">
            </div>
            <button class="btn btn-primary" type="submit">Обновить</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app_admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>