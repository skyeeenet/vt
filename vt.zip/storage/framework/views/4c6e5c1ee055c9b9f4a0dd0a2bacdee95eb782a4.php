<?php $__env->startSection('content'); ?>
    <div class="container">
        <form action="<?php echo e(route('admin.socials').'/update/'.$social->id); ?>" method="post">
            <?php echo e(csrf_field()); ?>

            <div class="form-group">
                <label for="value">Вид занятия</label>
                <input class="form-control" type="text" id="value" name="value" value="<?php echo e($social->value); ?>">
            </div>
            <div class="form-group">
                <label for="image">Иконка</label>
                <select class="form-control" name="image" id="image">
                    <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option <?php if($image->id == $social->image_id): ?> selected <?php endif; ?> value="<?php echo e($image->id); ?>"><?php echo e($image->id); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <button class="btn btn-primary" type="submit">Обновить</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app_admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>