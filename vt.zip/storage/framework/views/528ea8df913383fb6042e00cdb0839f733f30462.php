<?php $__env->startSection('content'); ?>
    <div class="container">
        <form action="<?php echo e(route('admin.administration').'/update'); ?>" method="post">
            <?php echo e(csrf_field()); ?>

            <div class="form-group">
                <label for="offset">Инвертировать недели ?</label>
                <select class="form-control" name="offset" id="offset">
                    <option <?php if($offset->value == 0): ?> selected <?php endif; ?> value="0">Да</option>
                    <option <?php if($offset->value == 1): ?> selected <?php endif; ?> value="1">Нет</option>
                </select>
            </div>
            <div class="form-group">
                <label for="admin">Роль администратора</label>
                <select class="form-control" name="admin" id="admin">
                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option  <?php if(!is_null($admin)): ?> <?php if($admin->id == $role->id): ?> selected <?php endif; ?> <?php endif; ?> value="<?php echo e($role->id); ?>"><?php echo e($role->public_name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group">
                <label for="lead">Роль старосты</label>
                <select class="form-control" name="lead" id="lead">
                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option <?php if(!is_null($admin)): ?> <?php if($lead->value == $role->id): ?> selected <?php endif; ?> <?php endif; ?> value="<?php echo e($role->id); ?>"><?php echo e($role->public_name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <button class="btn btn-primary" type="submit">Обновить</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app_admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>