<?php $__env->startSection('content'); ?>
    <div class="container">
        <form action="<?php echo e(route('admin.administration').'/update'); ?>" method="post">
            <?php echo e(csrf_field()); ?>

            <div class="form-group">
                <label for="offset">Инвертировать недели ?</label>
                <select class="form-control" name="offset" id="offset">
                    <option <?php if($offset->value == 0): ?> selected <?php endif; ?> value="0">Да</option>
                    <option <?php if($offset->value == 1): ?> selected <?php endif; ?> value="1">Нет</option>
                </select>
            </div>
            <button class="btn btn-primary" type="submit">Обновить</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app_admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>