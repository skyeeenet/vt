<?php $__env->startSection('content'); ?>
    <div class="container">
        <form action="<?php echo e(route('admin.roles').'/update/'.$role->id); ?>" method="post">
            <?php echo e(csrf_field()); ?>

            <div class="form-group">
                <label for="role">Роль</label>
                <input type="text" class="form-control" id="role" name="role" value="<?php echo e($role->value); ?>">
            </div>
            <div class="form-group">
                <label for="public">Публичное название</label>
                <input type="text" class="form-control" id="public" name="public" value="<?php echo e($role->public_name); ?>">
            </div>
            <button class="btn btn-primary" type="submit">Обновить</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app_admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>