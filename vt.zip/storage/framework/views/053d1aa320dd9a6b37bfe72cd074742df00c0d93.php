<?php $__env->startSection('content'); ?>
<div class="jumbotron">
    <div class="container">
        <div class="row">
            <div class="col-md-3">
                <ul>
                    <li><a href="#">Главная</a></li>
                    <li><a href="#">Header</a></li>
                    <li><a href="#">Footer</a></li>
                </ul>
            </div>
            <div class="col-md-9">test</div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_panel.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>