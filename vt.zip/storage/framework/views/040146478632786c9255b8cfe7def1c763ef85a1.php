<?php $__env->startSection('content'); ?>
    <?php if(Session::get('success') == 'true'): ?>
        <div class="alert-success d-flex justify-content-center pt-3 mb-4">
            <p>Пост отправлен на модерацию</p>
        </div>
    <?php endif; ?>
    <div class="d-flex justify-content-center">
        <?php if(count($errors) > 0): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
    <?php endif; ?>
    </div>
    <div class="d-flex justify-content-center">
        <form class="form-group col-md-6" method="post" action="<?php echo e(route('admin.content.adverts.create')); ?>">
            <?php echo csrf_field(); ?>
            <label for="advertShort">Заголовок (отображается на главной странице)</label>
            <input id="advertShort" class="form-control" type="text" name="advertShort" required value="<?php echo e(old('advertShort')); ?>">
            <label for="advertText">Содержание</label>
            <textarea class="form-control" name="advertText" id="advertText" cols="30" rows="10" required><?php echo e(old('advertText')); ?></textarea>
            <div class="form-group mt-2">
                <label for=""></label>
                <img src="<?php echo e(captcha_src()); ?>" alt="captcha" class="captcha-img" data-refresh-config="default"><a href="#" id="refresh"><small>обновить</small></a></p>
                <input class="form-control" type="text" name="captcha" placeholder="Ответ" required/>
            </div>
            <button type="submit" class="btn btn-primary mt-2">Отправить</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function () {
            $('.message a').click(function(e){
                e.preventDefault();
                $('form').animate({height: "toggle", opacity: "toggle"}, "slow");
            });
            $('#refresh').on('click',function(){
                var captcha = $('img.captcha-img');
                var config = captcha.data('refresh-config');
                $.ajax({
                    method: 'GET',
                    url: '/get_captcha/' + config,
                }).done(function (response) {
                    captcha.prop('src', response);
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('public.layouts.basic', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>