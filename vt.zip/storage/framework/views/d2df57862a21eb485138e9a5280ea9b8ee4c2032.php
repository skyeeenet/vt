<?php $__env->startSection('content'); ?>
    <div class="container">
        <h3 class="text-center mt-3">Добавить слайдер</h3>
        <form action="<?php echo e(route('admin.content.slider.store')); ?>" method="post">
            <?php echo e(csrf_field()); ?>

            <div class="form-group">
                <label for="title">Название слайдера</label>
                <input class="form-control" type="text" name="title" id="title">
            </div>
            <div class="form-group">
                <label for="image">Номер изображения</label>
                <select class="form-control" name="image" id="image">
                    <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($image->id); ?>"><?php echo e($image->id); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group">
                <label for="value">Содержание</label>
                <textarea class="form-control" name="value" id="value" cols="30" rows="10"></textarea>
            </div>
            <button class="btn btn-primary" type="submit">Добавить</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app_admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>