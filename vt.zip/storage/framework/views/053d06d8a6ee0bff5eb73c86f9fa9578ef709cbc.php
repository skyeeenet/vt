<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Редактирование верхнего слайдера</h2>
    <form action="<?php echo e(route('admin.content.upper-slider.create')); ?>" method="post">
        <?php echo e(csrf_field()); ?>

        <h3>Добавить слайд</h3>
        <div class="form-group">
            <label for="image-number">Номер изображения</label>
            <input type="text" class="form-control" name="image-number" id="image-number">
        </div>
        <div class="form-group">
            <label for="slide-text">Содержимое</label>
            <textarea class="form-control" name="slide-text" id="slide-text" rows="3"></textarea>
        </div>
        <button type="submit" class="btn btn-primary">Добавить</button>
    </form>
    <table class="table">
        <thead>
            <tr>
                <th>Изображение</th>
                <th>Содержание</th>
                <th>Редактировать</th>
                <th>Удалить</th>
            </tr>
        </thead>
        <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $slides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><img style="max-width: 300px; max-height: 300px;" src="<?php echo e($slide->image['url']); ?>" alt=""></td>
                <td><p><?php echo e($slide->value); ?></p></td>
                <td><a class="btn btn-primary" href="<?php echo e('/admin/content/upper-slider/edit/'.$slide->id); ?>"><i class="far fa-edit"></i></a></td>
                <td>
                    <form action="<?php echo e(route('admin.content.upper-slider').'/delete/'.$slide->id); ?>" method="post">
                        <?php echo e(csrf_field()); ?>

                        <button class="btn btn-danger"><i class="far fa-trash-alt"></i></button>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td>Нет данных</td>
                <td>Нет данных</td>
                <td>Нет данных</td>
                <td>Нет данных</td>
            </tr>
        <?php endif; ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app_admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>