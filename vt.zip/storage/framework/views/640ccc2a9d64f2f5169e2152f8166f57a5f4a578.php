<?php $__env->startSection('content'); ?>
    <div class=" container mt-5">
        <div class="content">
               <form action="<?php echo e(route('admin.content.posts.store')); ?>" method="post">
                   <?php echo e(csrf_field()); ?>

                   <select name="mini" id="mini" class="form-control">
                       <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <option value="<?php echo e($image->id); ?>"><?php echo e($image->id); ?></option>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   </select>
                   <div class="form-group">
                       <label for="title">Заголовок</label>
                       <input type="text" class="form-control" name="title" id="title">
                   </div>
                   <div class="form-group">
                       <label for="body">Содержание</label>
                       <textarea name="body" id="body"></textarea>
                   </div>
                   <button class="btn btn-primary" type="submit">Создать</button>
               </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app_admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>