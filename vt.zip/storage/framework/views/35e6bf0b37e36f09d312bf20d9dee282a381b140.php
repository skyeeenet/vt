<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2>Редактирование слайда</h2>
        <form action="<?php echo e('/admin/content/upper-slider/update/'.$upper->id); ?>" method="post">
            <?php echo e(csrf_field()); ?>

            <div class="form-group">
                <label for="image-number">Номер изображения</label>
                <input type="text" class="form-control" name="image-number" id="image-number" value="<?php echo e($upper->image_id); ?>">
            </div>
            <div class="form-group">
                <label for="slide-text">Содержимое</label>
                <textarea class="form-control" name="slide-text" id="slide-text" rows="3"><?php echo e($upper->value); ?></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Редактировать</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app_admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>