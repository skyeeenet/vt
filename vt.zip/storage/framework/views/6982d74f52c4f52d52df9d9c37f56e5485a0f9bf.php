<?php $__env->startSection('content'); ?>
    <div class="container">
        <h3>Добавить страницу</h3>
        <form action="<?php echo e(route('admin.pages').'/store'); ?>" method="post">
            <?php echo e(csrf_field()); ?>

            <div class="form-group">
                <label for="url">Адрес сайт</label>
                <input type="text" class="form-control" id="url" name="url" placeholder="/admin/site">
                <small class="form-text ">Вводить адрес относительно основного домена</small>
                <small class="form-text ">Пример: Полный адрес - http://localhost:8000/admin/content/images ; Вводить в поле url - /admin/content/images</small>
            </div>
            <div class="form-group">
                <label for="title">Заголовок страницы</label>
                <input type="text" class="form-control" id="title" name="title">
            </div>
            <button type="submit" class="btn btn-primary">Добавить</button>
        </form>
        <h3 class="mt-4">Все страницы</h3>
        <table class="table">
            <thead>
                <tr>
                    <th>Id страницы</th>
                    <th>Url страницы</th>
                    <th>Id страницы</th>
                    <th>Редактировать</th>
                    <th>Удалить</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($page->id); ?></td>
                    <td><?php echo e($page->url); ?></td>
                    <td><?php echo e($page->title); ?></td>
                    <td><a class="btn btn-primary" href="<?php echo e(route('admin.pages').'/edit/'.$page->id); ?>"><i class="far fa-trash-alt"></i></a></td>
                    <td>
                        <form action="<?php echo e(route('admin.pages').'/delete/'.$page->id); ?>" method="post">
                            <?php echo e(csrf_field()); ?>

                            <button class="btn btn-danger"><i class="far fa-edit"></i></button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td>Нет страниц</td>
                    <td>Нет страниц</td>
                    <td>Нет страниц</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app_admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>