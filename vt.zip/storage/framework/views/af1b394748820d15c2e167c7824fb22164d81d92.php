<?php $__env->startSection('content'); ?>
    <div class="container">
        <table class="table">
            <thead>
            <tr>
                <th>id</th>
                <th>Предмет</th>
                <th>Редактировать</th>
                <th>Удалить</th>
            </tr>
            </thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($subject->id); ?></td>
                    <td><?php echo e($subject->value); ?></td>
                    <td><a class="btn btn-primary" href="<?php echo e(route('admin.subjects').'/edit/'.$subject->id); ?>"><i class="far fa-edit"></i></a></td>
                    <td>
                        <form action="<?php echo e(route('admin.subjects').'/delete/'.$subject->id); ?>" method="post">
                            <?php echo e(csrf_field()); ?>

                            <button class="btn btn-danger" type="submit"><i class="far fa-trash-alt"></i></button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td>Предметы не найдены</td>
                    <td>Предметы не найдены</td>
                    <td>Предметы не найдены</td>
                    <td>Предметы не найдены</td>
                </tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app_admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>