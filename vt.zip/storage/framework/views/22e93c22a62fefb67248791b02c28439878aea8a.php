<?php $__env->startSection('content'); ?>
    <div class="container">
        <form action="<?php echo e(route('admin.bests').'/update/'.$best->id); ?>" method="post">
            <?php echo e(csrf_field()); ?>

            <div class="form-group">
                <label for="user">Выберите пользователя</label>
                <select class="form-control" name="user" id="user">
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option <?php if($user->id == $best->user_id): ?> selected <?php endif; ?> value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group">
                <label for="url">Ссылка на интервью</label>
                <input class="form-control" type="text" id="url" name="url" value="<?php echo e($best->interview_url); ?>">
            </div>
            <div class="form-group">
                <label for="title">Заголовок</label>
                <input class="form-control" type="text" id="title" name="title" value="<?php echo e($best->title); ?>">
            </div>
            <div class="form-group">
                <label for="description">Описание (191 символ максимум)</label>
                <textarea class="form-control" name="description" id="description" cols="30" rows="10"><?php echo e($best->description); ?></textarea>
            </div>
            <button class="btn btn-primary" type="submit">Обновить</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app_admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>