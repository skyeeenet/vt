<?php $__env->startSection('title'); ?>ПГТУ - Кафедра Информатики<?php $__env->stopSection(); ?>

<?php $__env->startSection('description'); ?>Приазовский государственный технический университет - Кафедра Информатики (ВТ). Поступление в ПГТУ на Кафедру Информатики<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <main>
        <section>
            <div class="container mt-3">
                <div class="row">
                    <div class="col-lg-8 slck vit_index">
                        <?php $__currentLoopData = Page::getSliderById(1)['images']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="sliderBLock" style="background-image: url('<?php echo e($slide->image['url']); ?>');">
                            <div class="d-flex flex-column justify-content-center align-items-center ">
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <!-- /.col-lg-8 -->
                    <div class="col-lg-4 declaration">
                        <div class="text-center pt-3 pb-2 declarationHead">
                            Объявления
                        </div>
                        <div class="d-flex flex-column justify-content-center align-items-center declaration-text">
                            <?php $__empty_1 = true; $__currentLoopData = Page::getAdsByAmount(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <p><a href="<?php echo e(route('singAdvert', $item->id)); ?>"><?php echo e($item->short); ?></a></p>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <p>Объявления отсутствуют</p>
                            <?php endif; ?>
                        </div>
                        <div class="d-flex justify-content-end">
                            <a class="link" href="<?php echo e(route('adverts')); ?>">Все объявления</a>
                        </div>
                    </div>
                    <!-- /.col-lg-4 -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container.mt-3.mb-3 -->
        </section>
        <section>
            <div class="container mt-5">
                <div class="w-100 d-flex flex-column align-items-center margin-bottom">
                    <a href="#">
                        <h2 class="title link">Недавние новости и события</h2>
                    </a>
                    <div class="d-flex flex-row justify-content-center specDoubledColorLine mt-2">
                        <div></div>
                        <div></div>
                    </div>
                </div>

                <div class="row">
                    <?php $__currentLoopData = $recent_posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-4 col-md-6 col-sm-12 mt-3">
                        <div style="height: 400px;" class="card">
                            <img style="height: 200px;" class="card-img-top" src="<?php echo e($recent->image['url']); ?>" alt="Card image cap">
                            <div class="card-body">
                                <h5 class="card-date"><?php echo e(date('d F Y', strtotime($recent->created_at))); ?></h5>
                                <h2 class="mt-3"><a class="card-title" href="<?php echo e('/news/'.$recent->slug); ?>"><?php echo e($recent->title); ?></a></h2>
                                <p class="card-text mt-4">
                                    <?php echo e($recent->short_body . '...'); ?>

                                </p>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </section>

        <section class="pb-5">
            <div class="container mt-5">
                <div class="w-100 d-flex flex-column align-items-center pt-5 mb-3">
                    <h2 class="title">Почему именно мы ?</h2>
                    <div class="d-flex flex-row justify-content-center specDoubledColorLine mt-2">
                        <div></div>
                        <div></div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-lg-4 col-md-6 col-sm-12 col-12 mt-5 mt-sm-5 mt-md-0 mt-lg-4">
                        <div class="adv-item d-flex flex-column align-items-center">
                            <img class="pt-3" src="./images/service-1.png" alt="">
                            <div class="p-3">
                                <h2 class="card-title t-transf-cap adv-title text-center">Заголовок номер 1</h2>
                                <p class="adv-main-text">
                                    Описание преимущества описание
                                    преимущества описание преисущества
                                    описание преимущества
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-12 col-12 mt-5 mt-sm-5 mt-md-0 mt-lg-4">
                        <div class="adv-item d-flex flex-column align-items-center">
                            <img class="pt-3" src="./images/service-1.png" alt="">
                            <div class="p-3">
                                <h2 class="card-title t-transf-cap adv-title text-center">Заголовок номер 1</h2>
                                <p class="adv-main-text">
                                    Описание преимущества описание
                                    преимущества описание преисущества
                                    описание преимущества
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-12 col-12 mt-md-5 mt-sm-5 mt-5 mt-lg-4">
                        <div class="adv-item d-flex flex-column align-items-center">
                            <img class="pt-3" src="./images/service-1.png" alt="">
                            <div class="p-3">
                                <h2 class="card-title t-transf-cap adv-title text-center">Заголовок номер 1</h2>
                                <p class="adv-main-text">
                                    Описание преимущества описание
                                    преимущества описание преисущества
                                    описание преимущества
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-12 col-12 mt-md-5 mt-sm-5 mt-5 mt-lg-4">
                        <div class="adv-item d-flex flex-column align-items-center">
                            <img class="pt-3" src="./images/service-1.png" alt="">
                            <div class="p-3">
                                <h2 class="card-title t-transf-cap adv-title text-center">Заголовок номер 1</h2>
                                <p class="adv-main-text">
                                    Описание преимущества описание
                                    преимущества описание преисущества
                                    описание преимущества
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-12 col-12 mt-md-5 mt-sm-5 mt-5 mt-lg-4">
                        <div class="adv-item d-flex flex-column align-items-center">
                            <img class="pt-3" src="./images/service-1.png" alt="">
                            <div class="p-3">
                                <h2 class="card-title t-transf-cap adv-title text-center">Заголовок номер 1</h2>
                                <p class="adv-main-text">
                                    Описание преимущества описание
                                    преимущества описание преисущества
                                    описание преимущества
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-12 col-12 mt-md-5 mt-sm-5 mt-5 mt-lg-4">
                        <div class="adv-item d-flex flex-column align-items-center">
                            <img class="pt-3" src="./images/service-1.png" alt="">
                            <div class="p-3">
                                <h2 class="card-title t-transf-cap adv-title text-center">Заголовок номер 1</h2>
                                <p class="adv-main-text">
                                    Описание преимущества описание
                                    преимущества описание преисущества
                                    описание преимущества
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <div id="bg-message"></div>
        <div id="message">
            <ul>
                <li><strong><i class="fas fa-times"></i></strong></li>
                <li><h3 class="text-center mb-3">Здравствуйте</h3></li>
                <li><p class="text-center">Сайт работает в тестовом режиме и все еще наполняется.</p></li>
                <li><p class="text-center">Просим прощения за неудобства</p></li>
            </ul>
        </div>
        <section>
            <div class="w-100 d-flex flex-column align-items-center mt-5">
                <h2 class="title">Лучшие студенты</h2>
                <div class="d-flex flex-row justify-content-center specDoubledColorLine mt-2">
                    <div></div>
                    <div></div>
                </div>
            </div>
            <div class="container mt-5">
                <div id="thebest">
                    <?php $bests = Page::getBests(); ?>
                    <?php $__currentLoopData = $bests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $best): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="thebest-container pt-5 pb-5 d-flex flex-column align-items-center">
                            <div class="best-image" style="background-image: url('<?php echo e($best['user']['image']); ?>');"></div>
                            <a class="d-block mt-3" href="">
                                <h3><?php echo e($best['user']['name']); ?></h3>
                            </a>
                            <p>Lorem ipsum dolor sit amet.</p>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </section>
    </main>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>

        function getCookie(name) {
            var matches = document.cookie.match(new RegExp(
                "(?:^|; )" + name.replace(/([\.$?*|{}\(\)\[\]\\\/\+^])/g, '\\$1') + "=([^;]*)"
            ));
            return matches ? decodeURIComponent(matches[1]) : undefined;
        }

        $(function() {

            if (!getCookie('test-accept')) {

                var date = new Date;
                date.setDate(date.getDate() + 2);

                document.cookie = "test-accept=true; expires=" + date.toUTCString();

                var $btn_close = $('#message ul li strong');
                var $bg_message = $('#bg-message');
                var $message = $('#message');

                $message.css('display', 'flex');
                $bg_message.css('display', 'block');

                $btn_close.click(function () {
                    $bg_message.fadeOut();
                    $message.fadeOut() ;
                });
            }
        });

    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('public.layouts.basic', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>