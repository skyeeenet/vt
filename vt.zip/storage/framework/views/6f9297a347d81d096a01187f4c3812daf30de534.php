<?php $__env->startSection('content'); ?>
    <div class="container">
        <h3 class="text-center mt-3 mb-3">Редактирование пользователя № <?php echo e($user->id); ?></h3>
        <form enctype="multipart/form-data" action="<?php echo e(route('admin.users').'/update/'.$user->id); ?>" method="post">
            <?php echo e(csrf_field()); ?>

            <div class="form-group">
                <label for="name">Имя</label>
                <input class="form-control" type="text" id="name" name="name" value="<?php echo e($user->name); ?>">
            </div>
            <div class="form-group">
                <label for="name">Почта</label>
                <input class="form-control" type="email" id="email" name="email" value="<?php echo e($user->email); ?>">
            </div>
            <div class="d-flex flex-column">
                <?php $__currentLoopData = $socials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $social): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="form-group">
                        <label for="name"><?php echo e($social->value); ?></label>
                        <p class="d-flex"><img class="mr-2" width="35px" height="35px" src="<?php echo e($social->image['url']); ?>" alt=""><input class="form-control" type="text" value="<?php echo e(\App\Models\SocialUser::where([
                                        'user_id' => $user->id,
                                        'social_id' => $social->id
                                        ])->first()['url']); ?>" name="<?php echo e($social->value); ?>"></p>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div>
                <p>Изображение профиля</p>
                <img style="max-width: 300px;" src="<?php if(is_null($user->image)): ?> /images/noimage.png <?php else: ?><?php echo e($user->image); ?> <?php endif; ?>" alt="Profile photo">
            </div>
            <div class="form-group">
                <label for="image">Обновить изображение</label>
                <input type="file" class="form-control-file" id="image" name="image">
            </div>
            <div class="form-group">
                <a class="btn btn-danger" href="<?php echo e(route('admin.users').'/deleteProfileImage/'.$user->id); ?>">Удалить изображение</a>
            </div>
            <div class="form-group">
                <label for="about">О себе</label><br>
                <textarea class="form-control" name="description" id="description" cols="100" rows="10"><?php echo e($user->description); ?></textarea>
            </div>
            <div class="form-group">
                <label for="role">Роль</label>
                <select class="form-control" name="role" id="role">
                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option <?php if($user->role_id == $role->id): ?> selected <?php endif; ?> value="<?php echo e($role->id); ?>"><?php echo e($role->value); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <button class="btn btn-primary" type="submit">Обновить</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app_admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>