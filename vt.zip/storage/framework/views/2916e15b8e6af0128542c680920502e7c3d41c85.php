<?php $__env->startSection('content'); ?>
    <main>
        <section>
            <div class="container">
                <div class="text-center">
                    <h1 class="title">Результаты поиска</h1>
                    <div class="d-flex flex-row justify-content-center specDoubledColorLine">
                        <div></div>
                        <div></div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-8 col-md-12">
                        <?php $__empty_1 = true; $__currentLoopData = $posts_arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="row news-post mt-5">
                            <div class="news-post-inner">
                                <img src="<?php echo e($post->image['url']); ?>" alt="">
                                <a href="<?php echo e($post['id']); ?>">
                                    <h2><?php echo e($post['title']); ?></h2>
                                </a>
                                <span class="span-with-line mr-3"><?php echo e($post->created_at); ?></span>
                                <span class="ml-3"><?php echo e($post->author['name']); ?></span>
                                <p class="">
                                    <?php echo e($post['short_body']); ?>

                                </p>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p>Записи не найдены</p>
                        <?php endif; ?>
                        <?php if(isset($ads_arr)): ?>
                            <?php $__currentLoopData = $ads_arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="row news-post mt-5">
                                    <div class="news-post-inner">
                                        <a href="<?php echo e($ad['id']); ?>">
                                            <h2><?php echo e($ad['short']); ?></h2>
                                        </a>
                                        <p><?php echo e($ad['value']); ?></p>
                                        <span class="span-with-line mr-3"><?php echo e($ad->created_at); ?></span>
                                        <span class="ml-3"><?php echo e($ad->author['name']); ?></span>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                    </div>
                    <div class="col-lg-4 col-md-12 d-flex flex-column align-items-center">
                        <div class="row mt-5">
                            <form class="search-form" action="<?php echo e(route('search')); ?>" method="get">
                                    <span><input name="search" type="text" placeholder="Поиск..."><button
                                                type="submit">НАЙТИ</button></span>
                            </form>
                        </div>
                        <div class="row mt-5 d-md-flex flex-md-column align-self-start ml-md-3 recent-posts">
                            <h3>Недавние посты</h3>
                            <a href="#">Заголовок поста номер один</a>
                            <a href="#">Заголовок поста номер два</a>
                            <a href="#">Заголовок поста номер три</a>
                        </div>
                    </div>
                </div>

            </div>
        </section>
    </main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('public.layouts.basic', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>