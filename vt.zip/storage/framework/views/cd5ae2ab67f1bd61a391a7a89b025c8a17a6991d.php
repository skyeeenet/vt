<?php $__env->startSection('content'); ?>
    <div class="container">
        <h3 class="mt-3 mb-3">Созданные тексты</h3>
        <a class="btn btn-primary mb-3" href="<?php echo e(route('admin.content.text.create')); ?>">Создать текст</a>
        <table class="table">
            <thead>
            <tr>
                <th>ID текста (используйте для вставки)</th>
                <th>Описание</th>
                <th>Редактировать</th>
                <th>Удалить</th>
            </tr>
            </thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $texts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $text): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($text->id); ?></td>
                    <td><?php echo e($text->description); ?></td>
                    <td><a class="btn btn-primary" href="<?php echo e(route('admin.content.text').'/edit/'.$text->id); ?>"><i class="far fa-edit"></i></a></td>
                    <td>
                        <form action="<?php echo e(route('admin.content.text').'/delete/'.$text->id); ?>" method="post">
                            <?php echo e(csrf_field()); ?>

                            <button class="btn btn-danger" type="submit"><i class="far fa-trash-alt"></i></button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td>Нет текста</td>
                <td>Нет текста</td>
                <td>Нет текста</td>
                <td>Нет текста</td>
            </tr>
            <?php endif; ?>
            </tbody>
        </table>
        <?php echo e($texts->links()); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function() {
            $('#body').summernote();
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app_admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>