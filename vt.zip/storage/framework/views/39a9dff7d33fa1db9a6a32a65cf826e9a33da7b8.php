<?php $__env->startSection('content'); ?>
    <main>
        <section>
            <div class="container">
                <div class="text-center mb-5">
                    <h1 class="title">
                        Профиль пользователя
                    </h1>
                    <div class="d-flex flex-row justify-content-center specDoubledColorLine">
                        <div></div>
                        <div></div>
                    </div>
                </div>
                <p class="text-center mb-5 roboto24">Добро пожаловать, <?php echo e($user->name); ?></p>
                <div class="row flex-column-reverse flex-xl-row">
                    <div class="col-xl-8 col-12 mt-5 mt-xl-0">
                        <div class="d-flex justify-content-between mb-3">
                            <b class="roboto24">О себе</b>
                            <a href="<?php echo e(route('user.edit')); ?>" class="roboto18lt btn btn-primary">Редактировать профиль</a>
                        </div>
                        <p class="roboto18"><?php echo e($user->description); ?></p>
                    </div>
                    <div class="col-xl-4 col-12 d-flex flex-column align-items-center d-xl-block">
                            <div><img style="max-width: 360px;max-height: 450px;" src="<?php if(is_null($user->image)): ?> /images/noimage.png <?php else: ?><?php echo e($user->image); ?> <?php endif; ?>" alt="" class="avatar"></div>
                        <div class="d-flex mt-3">
                            <?php $__empty_1 = true; $__currentLoopData = $socials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $social): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <?php if(!is_null($social->url)): ?>
                                <a class="mr-2" href="<?php echo e($social->url); ?>"><img width="35px" height="35px" src="<?php echo e(\App\Models\Social::where('id', $social->social_id)->first()->image['url']); ?>" alt=""></a>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p class="roboto18lt">Пользователь еще не добавил соц.сети</p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('public.layouts.basic', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>