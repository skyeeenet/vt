<?php $__env->startSection('content'); ?>
    <div class="container">
        <form action="<?php echo e(route('admin.subjects').'/update/'.$subject->id); ?>" method="post">
            <?php echo e(csrf_field()); ?>

            <div class="form-group">
                <label for="groupName">Название предмета</label>
                <input type="text" class="form-control" id="groupName" name="subject-name" value="<?php echo e($subject->value); ?>">
            </div>
            <button class="btn btn-primary" type="submit">Обновить</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app_admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>