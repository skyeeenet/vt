<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Объявления</h2>
    <form action="<?php echo e(route('admin.content.adverts.create')); ?>" method="post">
        <?php echo e(csrf_field()); ?>

        <h3>Добавить объявление</h3>
        <div class="form-group">
            <label for="advertShort">Краткое описание (выводится на главной странице)</label>
            <input type="text" class="form-control" id="advertShort" name="advertShort">
        </div>
        <div class="form-group">
            <label for="advertText">Содержание объявления</label>
            <input type="text" class="form-control" id="advertText" name="advertText">
        </div>
        <button type="submit" class="btn btn-primary">Добавить</button>
    </form>
    <table class="table">
        <thead>
            <tr>
                <th>Дата</th>
                <th>Автор</th>
                <th>Краткое описание</th>
                <th>Содержание</th>
                <th>Редактировать</th>
                <th>Удалить</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $adverts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $advert): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($advert->created_at); ?></td>
                <td><?php echo e($advert->author['name']); ?><br><?php echo e($advert->author['email']); ?></td>
                <td><?php echo e($advert->short); ?></td>
                <td><?php echo e($advert->value); ?></td>
                <td><a class="btn btn-primary" href="<?php echo e(route('admin.content.adverts').'/edit/'.$advert->id); ?>"><i class="far fa-edit"></i></a></td>
                <td>
                    <form action="<?php echo e(route('admin.content.adverts').'/delete/'.$advert->id); ?>" method="post">
                        <?php echo e(csrf_field()); ?>

                        <button type="submit" class="btn btn-danger"><i class="far fa-trash-alt"></i></button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td>Данные отсутствуют</td>
                <td>Данные отсутствуют</td>
                <td>Данные отсутствуют</td>
                <td>Данные отсутствуют</td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>
    <?php echo e($adverts->links()); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app_admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>