<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Объявления</h2>
    <form action="<?php echo e(route('admin.content.adverts.create')); ?>" method="post">
        <?php echo e(csrf_field()); ?>

        <h3>Добавить объявление</h3>
        <?php if(Session::get('success') == 'true'): ?>
            <div class="alert-success d-flex justify-content-center pt-3 mb-4">
                <p>Пост отправлен на модерацию</p>
            </div>
        <?php endif; ?>
        <div class="d-flex justify-content-center">
            <?php if(count($errors) > 0): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
        </div>
        <div class="form-group">
            <label for="advertShort">Заголовок (выводится на главной странице)</label>
            <input type="text" class="form-control" id="advertShort" name="advertShort" required>
        </div>
        <div class="form-group">
            <label for="advertText">Содержание объявления</label>
            <input type="text" class="form-control" id="advertText" name="advertText" required>
        </div>
        <div class="form-group mt-2">
            <label for=""></label>
            <img src="<?php echo e(captcha_src()); ?>" alt="captcha" class="captcha-img" data-refresh-config="default"><a href="#" id="refresh"><small>обновить</small></a></p>
            <input class="form-control" type="text" name="captcha" placeholder="Ответ" required/>
        </div>
        <button type="submit" class="btn btn-primary mb-3">Добавить</button>
    </form>
    <table class="table">
        <thead>
            <tr>
                <th>Дата</th>
                <th>Автор</th>
                <th>Краткое описание</th>
                <th>Опубликовано</th>
                <th>Редактировать</th>
                <th>Удалить</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $adverts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $advert): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($advert->created_at); ?></td>
                <td><?php echo e($advert->author['name']); ?><br><?php echo e($advert->author['email']); ?></td>
                <td><?php echo e($advert->short); ?></td>
                <td><?php echo e($advert->is_show); ?></td>
                <td><a class="btn btn-primary" href="<?php echo e(route('admin.content.adverts').'/edit/'.$advert->id); ?>"><i class="far fa-edit"></i></a></td>
                <td>
                    <form action="<?php echo e(route('admin.content.adverts').'/delete/'.$advert->id); ?>" method="post">
                        <?php echo e(csrf_field()); ?>

                        <button type="submit" class="btn btn-danger"><i class="far fa-trash-alt"></i></button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td>Данные отсутствуют</td>
                <td>Данные отсутствуют</td>
                <td>Данные отсутствуют</td>
                <td>Данные отсутствуют</td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>
    <?php echo e($adverts->links()); ?>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

    <script>
        $(document).ready(function () {
            $('.message a').click(function(e){
                e.preventDefault();
                $('form').animate({height: "toggle", opacity: "toggle"}, "slow");
            });
            $('#refresh').on('click',function(){
                var captcha = $('img.captcha-img');
                var config = captcha.data('refresh-config');
                $.ajax({
                    method: 'GET',
                    url: '/get_captcha/' + config,
                }).done(function (response) {
                    captcha.prop('src', response);
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app_admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>