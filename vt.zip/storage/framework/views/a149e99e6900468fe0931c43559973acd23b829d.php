<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" type="text/css" media="screen" href="/css/jquery.fancybox.min.css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <main>
        <div class="container-fluid">
            <div class="text-center my-5">
                <h1 class="title">Альбом</h1>
                <div class="d-flex flex-row justify-content-center specDoubledColorLine">
                    <div></div>
                    <div></div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-10 col-12 row no-gutters">
                    <?php $__currentLoopData = $urls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a class="col-lg-4 col-md-6 d-flex justify-content-center" data-fancybox="gallery" href="<?php echo e($url); ?>">
                        <div style="background-image: url('<?php echo e($url); ?>');"
                             class="card-gallery-container">
                        </div>
                    </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <aside class="d-flex flex-column col-lg-2 justify-content-start align-items-center align-items-xl-start mb-2 mb-lg-0">
                    <div class="mt-2 mb-2 alboomCategory recent-posts">
                        <h3>Категории</h3>
                        <?php $__currentLoopData = Page::getCategories(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e('/album/category/'.$category->id); ?>"><?php echo e($category->value); ?></a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </aside>
            </div>
            <?php if(isset($images)): ?>
            <div class="d-flex justify-content-center mt-3">
                <?php echo e($images->links()); ?>

            </div>
            <?php endif; ?>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('scripts/additional/jquery.fancybox.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('public.layouts.basic', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>