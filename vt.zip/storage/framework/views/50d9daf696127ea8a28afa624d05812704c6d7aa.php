<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2>Управление слайдерами</h2>
        <a class="btn btn-primary mt-3 mb-3" href="<?php echo e(route('admin.content.slider.create')); ?>">Создать слайдер</a>

        <table class="table">
            <thead>
            <tr>
                <th>Id слайдера</th>
                <th>Название слайдера</th>
                <th>Страница привязки</th>
                <th>Редактировать</th>
                <th>Удалить</th>
            </tr>
            </thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($slider->id); ?></td>
                    <td><?php echo e($slider->title); ?></td>
                    <td><?php echo e($slider->page['title']); ?></td>
                    <td><a class="btn btn-primary" href="<?php echo e(route('admin.content.slider').'/edit/'.$slider->id); ?>"><i class="far fa-edit"></i></a></td>
                    <td>
                        <form action="<?php echo e(route('admin.content.slider').'/delete/'.$slider->id); ?>" method="post">
                            <?php echo e(csrf_field()); ?>

                            <button type="submit" class="btn btn-danger"><i class="far fa-trash-alt"></i></button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td>Нет слайдеров</td>
                    <td>Нет слайдеров</td>
                    <td>Нет слайдеров</td>
                    <td>Нет слайдеров</td>
                </tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app_admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>