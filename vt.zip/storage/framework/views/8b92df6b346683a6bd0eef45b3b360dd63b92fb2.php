<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2>Редактирование слайда</h2>
        <form action="<?php echo e(route('admin.content.adverts').'/update/'.$advert->id); ?>" method="post">
            <?php echo e(csrf_field()); ?>

            <div class="form-group">
                <label for="advertShort">Описание</label>
                <textarea class="form-control" name="advertShort" id="advertShort" rows="3"><?php echo e($advert->short); ?></textarea>
            </div>
            <div class="form-group">
                <label for="advertText">Содержимое</label>
                <textarea class="form-control" name="advertText" id="advertText" rows="3"><?php echo e($advert->value); ?></textarea>
            </div>
            <div class="form-group">
                <label for="is_show">Открыть доступ ?</label>
                <select class="form-control" name="is_show" id="is_show">
                    <option selected value="1">Да</option>
                    <option value="0">Нет</option>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">Редактировать</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app_admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>