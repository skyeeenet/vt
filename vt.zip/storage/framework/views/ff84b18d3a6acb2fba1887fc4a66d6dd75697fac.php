<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2 class="text-center">Изображения</h2>

        <form action="<?php echo e(route('admin.content.images.store')); ?>" method="post">
            <?php echo e(csrf_field()); ?>

            <div class="form-group">
                <label for="url-image">URL адрес</label>
                <input type="text" class="form-control" name="url-image" id="url-image">
                <input type="hidden" name="type" value="remote">
            </div>
            <button type="submit" class="btn btn-primary">Добавить</button>
        </form>

        <form enctype="multipart/form-data" class="mt-4" action="<?php echo e(route('admin.content.images.store')); ?>" method="post">
            <?php echo e(csrf_field()); ?>

            <div class="form-group">
                <label for="server">Загрузить на сервер</label>
                <input type="file" class="form-control-file" id="server" name="image">
                <input type="hidden" name="type" value="local">
            </div>
            <div class="form-group">
                <input class="form-control" type="text" name="width" placeholder="Ширина (пиксели)">
                <input class="form-control mt-2" type="text" name="height" placeholder="Высота (пиксели)">
            </div>
            <button type="submit" class="btn btn-primary">Загрузить</button>
        </form>

        <table class="table">
            <thead>
                <tr>
                    <th>Изображение</th>
                    <th>Номер (используйте его для вставки)</th>
                    <th>Тип</th>
                    <th>Редактировать</th>
                    <th>Удалить</th>
                </tr>
            </thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><img style="max-width: 300px; max-height: 300px;" src="<?php echo e($image->url); ?>" alt="Отображение изображения"></td>
                    <td><?php echo e($image->id); ?></td>
                    <td><?php echo e($image->type); ?></td>
                    <td><a class="btn btn-primary" href="<?php echo e(route('admin.content.images').'/edit/'.$image->id); ?>"><i class="far fa-edit"></i></a></td>
                    <td>
                        <form action="<?php echo e(route('admin.content.images').'/delete/'.$image->id); ?>" method="post">
                            <?php echo e(csrf_field()); ?>

                            <button class="btn btn-danger" type="submit"><i class="far fa-trash-alt"></i></button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td>Нет данных</td>
                    <td>Нет данных</td>
                    <td>Нет данных</td>
                    <td>Нет данных</td>
                    <td>Нет данных</td>
                </tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app_admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>