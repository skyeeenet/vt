<?php $__env->startSection('content'); ?>
    <div class="container">
        <form action="<?php echo e(route('admin.socials.store')); ?>" method="post">
            <?php echo e(csrf_field()); ?>

            <?php $__empty_1 = true; $__currentLoopData = $socials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $social): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="form-group">
                    <label for="<?php echo e($social->id); ?>"><?php echo e($social->value); ?></label>
                    <p><img height="30px" width="30px" src="<?php echo e($social->image['url']); ?>" alt="<?php echo e($social->value); ?>">:
                        <input id="<?php echo e($social->id); ?>" name="<?php echo e($social->id); ?>" type="text" value="<?php echo e($user->social); ?>" placeholder="id пользователя">
                    </p>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p>Социальные сети временно не поддерживаются</p>
            <?php endif; ?>

            <button class="btn btn-primary" type="submit">обновить</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app_admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>