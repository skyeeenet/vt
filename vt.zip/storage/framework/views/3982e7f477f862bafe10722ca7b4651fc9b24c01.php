<?php $__env->startSection('content'); ?>
    <div class="container">
        <h3>Социальные сети</h3>
        <table class="table">
            <thead>
            <tr>
                <th>id</th>
                <th>Аватарка</th>
                <th>Имя</th>
                <th>Email</th>
                <th>Соц.сети</th>
                <th>Роль</th>
                <th>Создан</th>
                <th>Редактировать</th>
                <th>Удалить</th>
            </tr>
            </thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($user->id); ?></td>
                    <td><img width="200px" src="<?php echo e('/storage/profile_images/'.$user->image); ?>" alt=""></td>
                    <td><?php echo e($user->name); ?></td>
                    <td><?php echo e($user->email); ?></td>
                    <td><?php echo e($user->social); ?></td>
                    <td><?php echo e($user->role['value']); ?></td>
                    <td><?php echo e($user->created_at); ?></td>
                    <td><a class="btn btn-primary" href="<?php echo e(route('admin.users').'/edit/'.$user->id); ?>"><i class="far fa-edit"></i></a></td>
                    <td>
                        <form action="<?php echo e(route('admin.users').'/delete/'.$user->id); ?>" method="post">
                            <?php echo e(csrf_field()); ?>

                            <button class="btn btn-danger" type="submit"><i class="far fa-trash-alt"></i></button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td>Пользователи не найдены</td>
                    <td>Пользователи не найдены</td>
                    <td>Пользователи не найдены</td>
                    <td>Пользователи не найдены</td>
                    <td>Пользователи не найдены</td>
                    <td>Пользователи не найдены</td>
                    <td>Пользователи не найдены</td>
                    <td>Пользователи не найдены</td>
                    <td>Пользователи не найдены</td>
                </tr>
            <?php endif; ?>
            </tbody>
        </table>
        <?php echo e($users->links()); ?>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app_admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>