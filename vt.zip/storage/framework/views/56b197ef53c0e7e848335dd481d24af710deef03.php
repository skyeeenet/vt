<?php $__env->startSection('content'); ?>
<div class="container">
    <h3 class="text-center mt-3 mb-3">Раписание</h3>
    <select name="" id="group_id">
        <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($group->id); ?>"><?php echo e($group->value); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>

    <table class="table">
        <thead>
            <tr>
                <th>Неделя</th>
                <th>Пара</th>
                <th>День</th>
                <th>Группа</th>
                <th>Вид занятия</th>
                <th>Предмет</th>
                <th>Редактировать</th>
                <th>Удалить</th>
            </tr>
        </thead>
        <tbody id="table-body">

        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        var group = $('#group_id');

        group.ready(function () {

            req();
        });

        group.change(function () {

            req();
        });

        var req = function () {
            var group_id = group.val();

            $.ajax({
                url: 'schedule/'+group_id,
                dataType : "json",
                type: "GET",
                success: function(data){
                    printData(data);
                },
                error: function () {
                    alert('Во время выполнения запроса произошла ошибка');
                }
            });
        }

        var printData = function (data) {

            var body = $('#table-body');

            body.empty();

            data.forEach(function (item) {

                body.append('<tr>'+'<td>'+item['week']['value']+'</td>'
                        +'<td>'+item['number']+'</td>'
                        +'<td>'+item['day']+'</td>'
                        +'<td>'+item['group']['value']+'</td>'
                        +'<td>'+item['occupation']['value']+'</td>'
                        +'<td>'+item['subject']['value']+'</td>'
                        +'<td><a class="btn btn-primary" href="schedule/edit/'+item['id']+'"><i class="far fa-edit"></i></a></td>'
                        +'<td><form action="schedule/delete/'+item['id']+'" method="post"><?php echo e(csrf_field()); ?><button type="submit" class="btn btn-danger"><i class="far fa-trash-alt"></i></button></form></td>'
                    +'</tr>');
            });
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app_admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>