<?php $__env->startSection('content'); ?>
    <div class="container">
        <form action="<?php echo e(route('admin.conferences.store')); ?>" method="post">
            <?php echo e(csrf_field()); ?>

            <div class="form-group">
                <label for="type">Название конференции</label>
                <input type="text" class="form-control" id="type" name="type">
            </div>
            <div class="form-group">
                <label for="year">Год проведения (2017-2018)</label>
                <input type="text" class="form-control" id="year" name="year">
            </div>
            <button class="btn btn-primary" type="submit">Создать</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app_admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>