<?php $__env->startSection('content'); ?>
    <div class="container">
        <h3>Редактирование изображения № <?php echo e($image->id); ?></h3>
        <form action="<?php echo e(route('admin.content.images').'/update/'.$image->id); ?>" method="post">
            <?php echo e(csrf_field()); ?>

            <div class="form-group">
                <label for="url">URL</label>
                <input type="text" class="form-control" id="url" name="url" value="<?php echo e($image->url); ?>">
            </div>
            <div class="form-group">
                <label for="type">Тип</label>
                <select name="type" id="type">
                    <option <?php if($image->type == 'remote'): ?> selected <?php endif; ?> value="remote">Удаленный</option>
                    <option <?php if($image->type == 'local'): ?> selected <?php endif; ?> value="local">Локальный</option>
                </select>
            </div>
            <button class="btn btn-primary" type="submit">Обновить</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app_admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>