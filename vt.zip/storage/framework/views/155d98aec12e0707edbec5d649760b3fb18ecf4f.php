<?php $__env->startSection('content'); ?>
    <main>
        <section>
            <div class="container">
                <div class="d-flex flex-column align-items-center mb-5 mt-5 mt-lg-0">
                    <div class="text-center">
                        <h1 class="title">История кафедры</h1>
                        <div class="d-flex flex-row justify-content-center specDoubledColorLine">
                            <div></div>
                            <div></div>
                        </div>
                    </div>
                    <div class="d-flex w-100 flex-column justify-content-center align-items-center d-lg-block mt-5">
                        <div class="float-none float-lg-right mb-5 mb-lg-0 mx-3"><img width="300px" height="400px" src="<?php echo e($image); ?>" alt=""></div>
                        <p class="roboto16lt">
                            <?php echo $text; ?>

                        </p>
                    </div>
                </div>
                <div class="history_slick">
                    <?php $__currentLoopData = Page::getSliderById(2)['images']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="d-flex justify-content-center"><img src="<?php echo e($slide->image['url']); ?>" alt=""></div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="d-flex flex-column align-items-center mb-5 mt-5">
                    <p class="roboto16lt">
                        <?php echo Page::getTextById(5)['value']; ?>

                    </p>
                </div>
            </div>
        </section>
    </main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('public.layouts.basic', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>