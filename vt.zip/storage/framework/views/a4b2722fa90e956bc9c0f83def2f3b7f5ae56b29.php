<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2 class="text-center">Новости</h2>
        <a class="btn btn-primary" href="<?php echo e(route('admin.content.posts.create')); ?>">Создать новый пост</a>
        <h2 class="text-center">Все посты</h2>
        <table class="table">
            <thead>
                <tr>
                    <th>№</th>
                    <th>Автор</th>
                    <th>Дата создания</th>
                    <th>Миниатюра</th>
                    <th>Заголовок</th>
                    <th>Редактировать</th>
                    <th>Удалить</th>
                </tr>
            </thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($post->id); ?></td>
                    <td><?php echo e($post->author['name']); ?><br><?php echo e($post->author['email']); ?></td>
                    <td><?php echo e($post->created_at); ?></td>
                    <td><img style="max-width: 200px; max-height: 200px;" src="<?php echo e($post->image['url']); ?>" alt="mini-image"></td>
                    <td><a href="<?php echo e(route('admin.content.posts').'/'.$post->id); ?>"><?php echo e($post->title); ?></a></td>
                    <td><a class="btn btn-primary" href="<?php echo e(route('admin.content.posts').'/edit/'.$post->id); ?>"><i class="far fa-edit"></i></a></td>
                    <td>
                        <form action="<?php echo e(route('admin.content.posts').'/delete/'.$post->id); ?>" method="post">
                            <?php echo e(csrf_field()); ?>

                            <button class="btn btn-danger" type="submit"><i class="far fa-trash-alt"></i></button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td>Данные отсутствуют</td>
                    <td>Данные отсутствуют</td>
                    <td>Данные отсутствуют</td>
                    <td>Данные отсутствуют</td>
                    <td>Данные отсутствуют</td>
                    <td>Данные отсутствуют</td>
                </tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app_admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>