<?php $__env->startSection('content'); ?>
    <div class="container">
        <h3 class="text-center mt-3">Редактировать слайдер № <?php echo e($slider->id); ?></h3>
        <h5 class="text-center mt-3"><?php echo e($slider->title); ?></h5>
        <h4 class="mt-3">Добавить слайд</h4>
        <form action="<?php echo e(route('admin.content.slider').'/update/'.$slider->id); ?>" method="post">
            <?php echo e(csrf_field()); ?>

            <div class="form-group">
                <label for="image">Номер изображения</label>
                <select class="form-control" name="image" id="image">
                    <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($image->id); ?>"><?php echo e($image->id); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group">
                <label for="value">Содержание</label>
                <textarea class="form-control" name="value" id="value" cols="30" rows="10"></textarea>
            </div>
            <button class="btn btn-primary" type="submit">Добавить</button>
        </form>
        <h4 class="mt-3 mb-3">Текущие слайды</h4>
        <table class="table">
            <thead>
                <tr>
                    <th>Изображение</th>
                    <th>Содержание</th>
                    <th>Редактировать</th>
                    <th>Удалить</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $slider_images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><img width="300px" src="<?php echo e($image->image['url']); ?>" alt=""></td>
                    <td><?php echo e($image->value); ?></td>
                    <td><a class="btn btn-primary" href="<?php echo e('/admin/content/slider_image/edit/'.$image->id); ?>">Обновить</a></td>
                    <td>
                        <form action="<?php echo e('/admin/content/slider_image/delete/'.$image->id); ?>" method="post">
                            <?php echo e(csrf_field()); ?>

                            <button class="btn btn-danger">delete</button>
                        </form>
                    </td>
                </tr>    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?> 
                <tr>
                    <td>Нет изображений</td>
                    <td>Нет изображений</td>
                    <td>Нет изображений</td>
                    <td>Нет изображений</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app_admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>