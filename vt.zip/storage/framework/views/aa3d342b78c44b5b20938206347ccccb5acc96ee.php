<?php $__env->startSection('content'); ?>
    <div class="container">
        <table class="table">
            <thead>
                <tr>
                    <th>Пользователь</th>
                    <th>Ссылка на интервью</th>
                    <th>Заголовок</th>
                    <th>Описание</th>
                    <th>Редактировать</th>
                    <th>Удалить</th>
                </tr>
            </thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $bests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $best): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($best->user['name']); ?></td>
                    <td><?php echo e($best->interview_url); ?></td>
                    <td><?php echo e($best->title); ?></td>
                    <td><?php echo e($best->description); ?></td>
                    <td><a class="btn btn-primary" href="<?php echo e(route('admin.bests').'/edit/'.$best->id); ?>"><i class="far fa-edit"></i></a></td>
                    <td>
                        <form action="<?php echo e(route('admin.bests').'/delete/'.$best->id); ?>" method="post">
                            <?php echo e(csrf_field()); ?>

                            <button class="btn btn-danger" type="submit"><i class="far fa-trash-alt"></i></button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td>Нет данных</td>
                    <td>Нет данных</td>
                    <td>Нет данных</td>
                    <td>Нет данных</td>
                    <td>Нет данных</td>
                    <td>Нет данных</td>
                </tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app_admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>