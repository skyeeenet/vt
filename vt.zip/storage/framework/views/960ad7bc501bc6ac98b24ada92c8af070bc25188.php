<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php echo Page::getTextById(3)['value']; ?>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('public.layouts.basic', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>