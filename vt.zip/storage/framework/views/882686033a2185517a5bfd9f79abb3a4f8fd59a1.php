<?php $__env->startSection('content'); ?>
    <div class="container">
        <form action="<?php echo e(route('admin.schedule.store')); ?>" method="post">
            <?php echo e(csrf_field()); ?>

            <select class="form-control mt-4 mb-4" name="group-id">
                <?php $__empty_1 = true; $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <option value="<?php echo e($group->id); ?>"><?php echo e($group->value); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p>Данные отсутствуют</p>
                <?php endif; ?>
            </select>
            <select class="form-control mt-4 mb-4" name="subject-id">
                <?php $__empty_1 = true; $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <option value="<?php echo e($subject->id); ?>"><?php echo e($subject->value); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p>Данные отсутствуют</p>
                <?php endif; ?>
            </select>
            <select class="form-control mt-4 mb-4" name="week-id">
                <?php $__empty_1 = true; $__currentLoopData = $weeks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $week): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <option value="<?php echo e($week->id); ?>"><?php echo e($week->value); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p>Данные отсутствуют</p>
                <?php endif; ?>
            </select>
            <label for="number">Пара</label>
            <select class="form-control mb-4" name="number" id="number">
                <option value="1">1 Пара</option>
                <option value="2">2 Пара</option>
                <option value="3">3 Пара</option>
                <option value="4">4 Пара</option>
                <option value="5">5 Пара</option>
                <option value="6">6 Пара</option>
            </select>
            <label for="day">День</label>
            <select class="form-control mb-4" name="day" id="day">
                <option value="Понедельник">Понедельник</option>
                <option value="Вторник">Вторник</option>
                <option value="Среда">Среда</option>
                <option value="Четверг">Четверг</option>
                <option value="Пятница">Пятница</option>
                <option value="Суббота">Суббота</option>
                <option value="Воскресенье">Воскресенье</option>
            </select>
            <label for="occupation">Вид занятия</label>
            <select class="form-control mb-4" name="occupation-id" id="occupation">
                <?php $__currentLoopData = $occupations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $occupation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($occupation->id); ?>"><?php echo e($occupation->value); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <button class="btn btn-primary" type="submit">Создать</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app_admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>