<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col">
                <h2><?php echo e($post->title); ?></h2>
            </div>
        </div>
        <div class="row mt-3">
            <div class="col">
                <?php echo $post->body; ?>

            </div>
        </div>
        <div class="row mt-3">
            <div class="col">
                <p>Автор: <?php echo e(!$post->author['name']); ?></p>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app_admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>