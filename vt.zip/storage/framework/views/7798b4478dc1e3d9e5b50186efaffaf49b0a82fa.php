<?php $__env->startSection('content'); ?>
    <div class="container">
        <table class="table">
            <thead>
                <tr>
                    <th>Пользователь</th>
                    <th>Должность</th>
                    <th>Кафедра</th>
                    <th>Email</th>
                    <th>Телефон</th>
                    <th>Facebook</th>
                    <th>НТБ</th>
                    <th>Редактировать</th>
                    <th>Удалить</th>
                </tr>
            </thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $lecturers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lecturer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($lecturer->user['name']); ?></td>
                    <td><?php echo e($lecturer->position); ?></td>
                    <td><?php echo e($lecturer->department); ?></td>
                    <td><?php echo e($lecturer->email); ?></td>
                    <td><?php echo e($lecturer->phone); ?></td>
                    <td><?php echo e($lecturer->facebook); ?></td>
                    <td><?php echo e($lecturer->ntb); ?></td>
                    <td><a class="btn btn-primary" href="<?php echo e(route('admin.lecturers').'/edit/'.$lecturer->id); ?>"><i class="far fa-edit"></i></a></td>
                    <td>
                        <form action="<?php echo e(route('admin.lecturers').'/delete/'.$lecturer->id); ?>" method="post">
                            <?php echo e(csrf_field()); ?>

                            <button class="btn btn-danger" type="submit"><i class="far fa-trash-alt"></i></button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td>Преподаватели не найдены</td>
                    <td>Преподаватели не найдены</td>
                    <td>Преподаватели не найдены</td>
                    <td>Преподаватели не найдены</td>
                    <td>Преподаватели не найдены</td>
                    <td>Преподаватели не найдены</td>
                    <td>Преподаватели не найдены</td>
                    <td>Преподаватели не найдены</td>
                </tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app_admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>