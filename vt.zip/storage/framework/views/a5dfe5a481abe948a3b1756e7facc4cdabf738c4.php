<?php $__env->startSection('title'); ?><?php echo e($post['short']); ?> - ПГТУ - Кафедра Информатики<?php $__env->stopSection(); ?>
<?php $__env->startSection('description'); ?><?php echo e($post['short'] . ' - '. $post->author['name']); ?>. ПГТУ - Кафедра Информатики<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <main>
        <section>
            <div class="container">
                <div class="text-center my-5">
                    <h1 class="title">Объявления</h1>
                    <div class="d-flex flex-row justify-content-center specDoubledColorLine">
                        <div></div>
                        <div></div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-8 mx-3 mx-md-0">
                        <div class="row flex-column mt-4">
                            <p class="roboto18lt"><?php echo e($post['value']); ?></p>
                            <div class="roboto14md d-flex mt-2">
                                <p> Дата: <span><?php echo e($post->created_at); ?></span></p>
                                <p class="ml-4">Автор: <span><?php echo e($post->author['name']); ?></span></p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-12 d-flex flex-column align-items-center align-items-lg-start mb-5 mb-lg-0">
                        <div class="">
                            <form class="search-form m-0" action="<?php echo e(route('searchads')); ?>" method="get">
                                    <span><input type="text" name="search" placeholder="Поиск..."><button
                                                type="submit">НАЙТИ</button></span>
                            </form>
                        </div>
                        <div class="d-flex flex-column mt-5 ml-0 ml-lg-4 recent-posts">
                            <h3>Недавние посты</h3>
                            <?php $__currentLoopData = Page::getLatestNews(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="/news/<?php echo e($item->id); ?>"><?php echo e($item->title); ?></a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('public.layouts.basic', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>