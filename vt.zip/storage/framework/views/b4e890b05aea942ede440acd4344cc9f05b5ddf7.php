<?php $__env->startSection('content'); ?>
    <main>
        <section>
            <div class="container">
                <div class="text-center mb-5">
                    <h1 class="title">
                        Профиль пользователя
                    </h1>
                    <div class="d-flex flex-row justify-content-center specDoubledColorLine">
                        <div></div>
                        <div></div>
                    </div>
                </div>
                <p class="text-center mb-5 roboto24">Добро пожаловать, <?php echo e($user->name); ?></p>
                <div class="row flex-column-reverse flex-xl-row">
                    <div class="col-xl-8 col-12 mt-5 mt-xl-0">
                        <form class="w-100 d-flex flex-column" action="<?php echo e(route('user.update')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="d-flex justify-content-between mb-3">
                                <b class="roboto24">О себе</b>
                                <button type="submit" class="btn btn-primary">Обновить</button>
                            </div>
                            <div class="form-group">
                                <label for="name">Редактировать имя</label>
                                <input class="form-control" type="text" value="<?php echo e($user->name); ?>" name="name">
                            </div>
                            <div class="form-group">
                                <textarea class="form-control" name="description" cols="100" rows="10"><?php echo e($user->description); ?></textarea>
                            </div>
                            <p class="roboto18lt">Email: <b><?php echo e($user->email); ?></b></p>
                            <div class="d-flex flex-column">
                                <?php $__currentLoopData = $socials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $social): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="form-group">
                                        <label for="name"><?php echo e($social->value); ?></label>
                                        <p class="d-flex"><img class="mr-2" width="35px" height="35px" src="<?php echo e($social->image['url']); ?>" alt=""><span><?php echo e($social->url); ?></span><input placeholder="id" class="form-control" type="text" value="<?php echo e(str_replace($social->url,'',\App\Models\SocialUser::where([
                                        'user_id' => $user->id,
                                        'social_id' => $social->id
                                        ])->first()['url'])); ?>" name="<?php echo e($social->value); ?>"></p>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </form>
                    </div>
                    <div class="col-xl-4 col-12 d-flex flex-column align-items-center d-xl-block">
                        <form action="<?php echo e(route('user.update')); ?>" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div><img style="max-width: 360px;max-height: 450px;" src="<?php if(is_null($user->image)): ?> /images/noimage.png <?php else: ?><?php echo e($user->image); ?> <?php endif; ?>" alt="" class="avatar">
                                <div class="w-100 mt-3 mb-3">
                                    <div class="custom-file" style="width: 96%;">
                                        <input type="file" class="custom-file-input" id="customFile" name="image">
                                        <label class="custom-file-label" for="customFile">Обзор...</label>
                                    </div>
                                </div>
                                <div class="d-flex justify-content-center w-100">
                                    <button class="btn btn-primary w-100" type="submit">Загрузить</button>
                                </div>
                            </div>
                        </form>
                        <form class="d-flex justify-content-center w-100 mt-2" action="<?php echo e(route('user.delete')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-danger w-100">Удалить</button>
                        </form>
                    </div>
                </div>
            </div>
        </section>
    </main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('public.layouts.basic', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>