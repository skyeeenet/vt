<?php $__env->startSection('content'); ?>
    <div class="container">
        <form action="<?php echo e(route('admin.weeks.store')); ?>" method="post">
            <?php echo e(csrf_field()); ?>

            <div class="form-group">
                <label for="weekName">Неделя</label>
                <input type="text" class="form-control" id="weekName" name="week-name">
            </div>
            <button class="btn btn-primary" type="submit">Создать</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app_admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>