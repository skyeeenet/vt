<?php $__env->startSection('content'); ?>
    <div class="container">
        <form action="<?php echo e(route('admin.albums').'/update/'.$album->id); ?>" method="post">
            <?php echo e(csrf_field()); ?>

            <div class="form-group">
                <label for="value">Название альбома</label>
                <input type="text" class="form-control" id="groupName" name="value" value="<?php echo e($album->value); ?>">
            </div>
            <button class="btn btn-primary" type="submit">Обновить</button>
        </form>
        <h3 class="text-center">Добавить категорию</h3>
        <form action="<?php echo e('/admin/albums_categories/store'); ?>" method="post">
            <?php echo e(csrf_field()); ?>

            <div class="form-group">
                <label for="category">Категории</label>
                <select class="form-control" name="category" id="category">
                    <?php $__currentLoopData = $allCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($category->id); ?>"><?php echo e($category->value); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <input type="hidden" name="album" value="<?php echo e($album->id); ?>">
            <button type="submit" class="btn btn-primary">Добавить</button>
        </form>
        <h3 class="text-center">Категории</h3>
        <table class="table">
            <thead>
            <tr>
                <th>Категория</th>
                <th>Удалить</th>
            </tr>
            </thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($category->value); ?></td>
                    <td>
                        <form action="<?php echo e('/admin/albums_categories/'.'delete/'.$category->id); ?>" method="post">
                            <?php echo e(csrf_field()); ?>

                            <button class="btn btn-danger" type="submit"><i class="far fa-trash-alt"></i></button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <td>Категорий не закреплены</td>
                <td>Категорий не закреплены</td>
                <td>Категорий не закреплены</td>
            <?php endif; ?>
            </tbody>
        </table>
        <h3 class="text-center">Добавить изображение</h3>
        <form action="<?php echo e('/admin/albums_images/store'); ?>" method="post">
            <?php echo e(csrf_field()); ?>

            <div class="form-group">
                <label for="image">Изображение</label>
                <select class="form-control" name="image" id="image">
                    <?php $__currentLoopData = $allImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($image->id); ?>"><?php echo e($image->id); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <input type="hidden" name="album" value="<?php echo e($album->id); ?>">
            <button type="submit" class="btn btn-primary">Добавить</button>
        </form>
        <h3 class="text-center">Изображения</h3>
        <table class="table">
            <thead>
                <tr>
                    <th>Изображение</th>
                    <th>Удалить</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><img width="200px" src="<?php echo e($image->url); ?>" alt=""></td>
                        <td>
                            <form action="<?php echo e('/admin/albums_images/'.'delete/'.$image->id); ?>" method="post">
                                <?php echo e(csrf_field()); ?>

                                <button class="btn btn-danger" type="submit"><i class="far fa-trash-alt"></i></button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <td>Альбом пуст</td>
                    <td>Альбом пуст</td>
                    <td>Альбом пуст</td>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app_admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>