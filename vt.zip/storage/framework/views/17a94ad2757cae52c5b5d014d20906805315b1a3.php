<?php $__env->startSection('content'); ?>
    <div class="container">
        <form action="<?php echo e(route('admin.conferences').'/update/'.$conference->id); ?>" method="post">
            <?php echo e(csrf_field()); ?>

            <div class="form-group">
                <label for="type">Название конференции</label>
                <input type="text" class="form-control" id="type" name="type" value="<?php echo e($conference->type); ?>">
            </div>
            <div class="form-group">
                <label for="year">Год проведения</label>
                <input type="text" class="form-control" id="year" name="year" value="<?php echo e($conference->year); ?>">
            </div>
            <button class="btn btn-primary" type="submit">Обновить</button>
        </form>

        <h5 class="text-center">Информация о конференции</h5>

        <form action="<?php echo e(route('admin.conferences').'/info/update/'.$info->id); ?>" method="post">
            <?php echo e(csrf_field()); ?>

            <div class="form-group">
                <label for="place">Место проведения</label>
                <input type="text" class="form-control" id="place" name="place" value="<?php echo e($info->place); ?>">
            </div>
            <div class="form-group">
                <label for="year">Время проведения</label>
                <input type="text" class="form-control" id="year" name="time" value="<?php echo e($info->time); ?>">
            </div>
            <div class="form-group">
                <label for="year">Председатель</label>
                <input type="text" class="form-control" id="year" name="chairman" value="<?php echo e($info->chairman); ?>">
            </div>
            <div class="form-group">
                <label for="year">Секретарь</label>
                <input type="text" class="form-control" id="year" name="secretary" value="<?php echo e($info->secretary); ?>">
            </div>
            <div class="form-group">
                <label for="year">Длительность регистрации</label>
                <input type="text" class="form-control" id="year" name="duration" value="<?php echo e($info->duration); ?>">
            </div>
            <div class="form-group">
                <label for="show">Отображать возможность регистрации ?</label>
                <select class="form-control" name="show" id="show">
                    <option <?php if($info->show_reg == 1): ?> selected <?php endif; ?> value="1">Да</option>
                    <option <?php if($info->show_reg == 0): ?> selected <?php endif; ?> value="0">Нет</option>
                </select>
            </div>
            <button class="btn btn-primary" type="submit">Обновить</button>
        </form>
        <h5 class="text-center">Добавить докладчика</h5>
        <form action="<?php echo e(route('admin.conferences').'/users/store/'.$conference->id); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="theme">Темы докладов</label>
                <input class="form-control" type="text" id="theme" name="theme">
            </div>
            <div class="form-group">
                <label for="speaker">Докладчик</label>
                <input class="form-control" type="text" id="speaker" name="speaker">
            </div>
            <div class="form-group">
                <label for="head">Руководитель</label>
                <input class="form-control" type="text" id="head" name="head">
            </div>
            <button type="submit" class="btn btn-primary mb-2">Добавить</button>
        </form>

        <table  class="table">
            <thead>
                <tr>
                    <th>Тема доклада</th>
                    <th>Докладчик</th>
                    <th>Руководитель</th>
                    <th>Удалить</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($user->theme); ?></td>
                        <td><?php echo e($user->speaker); ?></td>
                        <td><?php echo e($user->head); ?></td>
                        <td>
                            <form action="<?php echo e(route('admin.conferences').'/users/delete/'.$user->id); ?>" method="post">
                                <?php echo e(csrf_field()); ?>

                                <button class="btn btn-danger" type="submit"><i class="far fa-trash-alt"></i></button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td>Пусто !</td>
                    <td>Пусто !</td>
                    <td>Пусто !</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app_admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>