<?php $__env->startSection('content'); ?>
    <div class="container">
        <table class="table">
            <thead>
                <tr>
                    <th>Тип</th>
                    <th>Начало</th>
                    <th>Конец</th>
                    <th>Редактировать</th>
                    <th>Удалить</th>
                </tr>
            </thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $graphics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $graphic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($graphic->type); ?></td>
                    <td><?php echo e($graphic->begin); ?></td>
                    <td><?php echo e($graphic->end); ?></td>
                    <td><a class="btn btn-primary" href="<?php echo e(route('admin.graphics').'/edit/'.$graphic->id); ?>"><i class="far fa-edit"></i></a></td>
                    <td>
                        <form action="<?php echo e(route('admin.graphics').'/delete/'.$graphic->id); ?>" method="post">
                            <?php echo e(csrf_field()); ?>

                            <button class="btn btn-danger" type="submit"><i class="far fa-trash-alt"></i></button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td>Графики не найдены</td>
                    <td>Графики не найдены</td>
                    <td>Графики не найдены</td>
                    <td>Графики не найдены</td>
                    <td>Графики не найдены</td>
                </tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app_admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>