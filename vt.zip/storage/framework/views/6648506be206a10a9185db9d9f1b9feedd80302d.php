<?php $__env->startSection('content'); ?>
    <div class="container d-flex flex-column align-items-center">
        <div class="jumbotron w-25">
            <form action="<?php echo e(route('admin.schedule').'/update/'.$schedule->id); ?>" method="post">
                <?php echo e(csrf_field()); ?>

                <label for="week">Неделя</label>
                <div class="form-group">
                    <select class="form-control" name="week_id" id="week">
                        <?php $__empty_1 = true; $__currentLoopData = $weeks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $week): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <option <?php if($week->id == $schedule->week_id): ?> selected <?php endif; ?> value="<?php echo e($week->id); ?>"><?php echo e($week->value); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <option value="">Пусто</option>
                        <?php endif; ?>
                    </select>
                </div>
                <label for="group">Группа</label>
                <div class="form-group">
                    <select class="form-control" name="group_id" id="group">
                        <?php $__empty_1 = true; $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <option <?php if($group->id == $schedule->group_id): ?> selected <?php endif; ?> value="<?php echo e($group->id); ?>"><?php echo e($group->value); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <option value="">Пусто</option>
                        <?php endif; ?>
                    </select>
                </div>
                <label for="subject">Предмет</label>
                <div class="form-group">
                    <select class="form-control" name="subject_id" id="subject">
                        <?php $__empty_1 = true; $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <option <?php if($subject->id == $schedule->subject_id): ?> selected <?php endif; ?> value="<?php echo e($subject->id); ?>"><?php echo e($subject->value); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <option value="">Пусто</option>
                        <?php endif; ?>
                    </select>
                </div>
                <label for="number">Пара</label>
                <div class="form-group">
                    <select class="form-control" name="number" id="number">
                        <option <?php if($schedule->number == 1): ?> selected <?php endif; ?> value="1">1</option>
                        <option <?php if($schedule->number == 2): ?> selected <?php endif; ?> value="2">2</option>
                        <option <?php if($schedule->number == 3): ?> selected <?php endif; ?> value="3">3</option>
                        <option <?php if($schedule->number == 4): ?> selected <?php endif; ?> value="4">4</option>
                        <option <?php if($schedule->number == 5): ?> selected <?php endif; ?> value="5">5</option>
                        <option <?php if($schedule->number == 6): ?> selected <?php endif; ?> value="6">6</option>
                    </select>
                </div>
                <label for="day">День</label>
                <select class="form-control mt-4 mb-4" name="day" id="day">
                    <option <?php if($schedule->number == 'Понедельник'): ?> selected <?php endif; ?> value="Понедельник">Понедельник</option>
                    <option <?php if($schedule->number == 'Вторник'): ?> selected <?php endif; ?> value="Вторник">Вторник</option>
                    <option <?php if($schedule->number == 'Среда'): ?> selected <?php endif; ?> value="Среда">Среда</option>
                    <option <?php if($schedule->number == 'Четверг'): ?> selected <?php endif; ?> value="Четверг">Четверг</option>
                    <option <?php if($schedule->number == 'Пятница'): ?> selected <?php endif; ?> value="Пятница">Пятница</option>
                    <option <?php if($schedule->number == 'Суббота'): ?> selected <?php endif; ?> value="Суббота">Суббота</option>
                    <option <?php if($schedule->number == 'Воскресенье'): ?> selected <?php endif; ?> value="Воскресенье">Воскресенье</option>
                </select>
                <label for="occupation">Вид занятия</label>
                <select class="form-control mb-4" name="occupation-id" id="occupation">
                    <?php $__currentLoopData = $occupations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $occupation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option <?php if($occupation->id == $schedule->occupation_type_id): ?> selected <?php endif; ?> value="<?php echo e($occupation->id); ?>"><?php echo e($occupation->value); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <label for="lecturer">Преподаватель</label>
                <div class="form-group">
                    <select class="form-control" name="lecturer_id" id="lecturer">
                        <?php $__empty_1 = true; $__currentLoopData = $lecturers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lecturer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <option <?php if($lecturer->id == $schedule->lecturer_id): ?> selected <?php endif; ?> value="<?php echo e($lecturer->id); ?>"><?php echo e($lecturer['user']['name']); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <option value="">Пусто</option>
                        <?php endif; ?>
                    </select>
                </div>
                <button class="btn btn-primary" type="sumbit">Обновить</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app_admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>